------------------------------------------------------------------------------------------------
COMPLIATION & EXECUTION
This program should have a standard compliation and execution procedure.

gmake4 cmake;
make;
./A1;

There may be an issue if C++ 11 isn't used as I implemented a lambda function for my avatar vertex generation. 

------------------------------------------------------------------------------------------------
MANUAL:
The only additional functionality of this program is the option of rendering the cubes as wireframes,
as sometimes they obscure the avatar. This should be easily accessable using ImGui.
------------------------------------------------------------------------------------------------